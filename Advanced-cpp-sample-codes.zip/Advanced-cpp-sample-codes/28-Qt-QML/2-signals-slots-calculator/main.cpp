#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>

class Calculator : public QObject {
    Q_OBJECT
public:
    explicit Calculator(QObject *parent = nullptr) : QObject(parent) {}

public slots:
    void add(double a, double b) {
        emit resultChanged(a + b);
    }

signals:
    void resultChanged(double result);
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QWidget window;
    window.setWindowTitle("RR Calculator");
    auto *outer = new QVBoxLayout(&window);

    auto *row = new QHBoxLayout();
    auto *inputA = new QLineEdit("2");
    auto *inputB = new QLineEdit("3");
    auto *addButton = new QPushButton("+");
    row->addWidget(inputA);
    row->addWidget(addButton);
    row->addWidget(inputB);
    outer->addLayout(row);

    auto *resultLabel = new QLabel("Result: (not calculated yet)");
    outer->addWidget(resultLabel);

    Calculator calc;
    QObject::connect(&calc, &Calculator::resultChanged, [&](double result) {
        resultLabel->setText(QString("Result: %1").arg(result));
    });
    QObject::connect(addButton, &QPushButton::clicked, [&]() {
        calc.add(inputA->text().toDouble(), inputB->text().toDouble());
    });

    window.show();
    return app.exec();
}

#include "main.moc"



















// --------------------------------------------------------------------------
// Step-by-step execution trace (clicking "+" once, with the default 2 and 3)
// --------------------------------------------------------------------------
// STEP 1  Window opens. inputA->text() == "2", inputB->text() == "3".
//         resultLabel reads "Result: (not calculated yet)".
// STEP 2  User clicks "+": the clicked lambda runs.
//         inputA->text().toDouble() -> 2.0
//         inputB->text().toDouble() -> 3.0
// STEP 3  calc.add(2.0, 3.0) runs: inside it, a=2.0, b=3.0, so
//         emit resultChanged(5.0) fires.
// STEP 4  Qt looks up every slot connected to calc's resultChanged signal
//         and calls each one with result == 5.0. There is exactly one here:
//         the lambda that does resultLabel->setText("Result: 5").
// STEP 5  resultLabel now reads "Result: 5" on screen.
// STEP 6  User changes inputB to "10" and clicks "+" again:
//         inputA->text().toDouble() -> 2.0, inputB->text().toDouble() -> 10.0
//         calc.add(2.0, 10.0) -> emit resultChanged(12.0) -> label becomes
//         "Result: 12". Each click re-runs STEPS 2-5 independently; nothing
//         from the previous click is reused except the widgets themselves.
